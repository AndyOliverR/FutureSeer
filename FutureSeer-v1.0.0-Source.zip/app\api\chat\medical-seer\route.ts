import { NextRequest, NextResponse } from 'next/server'
import { enforceToolSeerGate } from '@/lib/enforceToolSeerGate';
import { devLog } from '@/lib/devLogger';
import { callTextAI } from '@/lib/aiStructuredOutput'
import {
  buildMedicalAstrologyState,
  classifyMedicalAstrologyQuestion,
  getMedicalAstrologySliceForQuestionType,
  MEDICAL_DISCLAIMER,
  type MedicalAstrologyChartPayload,
} from '@/lib/medicalAstrologySeerState'
import { buildMedicalAstrologySeerSystemPrompt } from '@/lib/medicalAstrologySeerPrompts'

const REFUSAL_PHRASE = 'This question requires professional medical evaluation.'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const __toolSeerGate = await enforceToolSeerGate(request, body, 'medical_astrology_seer', {
      blockedResponseFormat: 'json',
    })
    if (__toolSeerGate) return __toolSeerGate
    const { question, analysis, chartData, comprehensiveProfile, userProfile } = body

    if (!question) {
      return NextResponse.json(
        { error: 'Question is required' },
        { status: 400 }
      )
    }

    // Early refusal: classify question and refuse diagnosis/treatment/emergency
    const questionType = classifyMedicalAstrologyQuestion(question)
    if (questionType === 'refusal') {
      return NextResponse.json({
        response: REFUSAL_PHRASE,
        refused: true,
        timestamp: new Date().toISOString(),
      })
    }

    // Payload normalization: derive MedicalAstrologyChartPayload from analysis, chartData, or comprehensiveProfile
    // Medical page sends analysis = { chart, healthIndicators, ... } (data object); API also accepts analysis.data.chart (nested).
    let payload: MedicalAstrologyChartPayload
    if (analysis?.data?.chart) {
      payload = { data: analysis.data }
    } else if (analysis?.chart) {
      const data = { ...analysis }
      let chart = data.chart && typeof data.chart === 'object' ? { ...data.chart } : data.chart
      if (chart && Array.isArray(chart.planets)) {
        const byName: Record<string, { sign?: string; house?: number }> = {}
        chart.planets.forEach((p: { name?: string; sign?: string; house?: number }) => {
          const name = p?.name
          if (name) byName[name] = { sign: p.sign, house: p.house }
        })
        chart = { ...chart, planets: byName }
      }
      data.chart = chart
      payload = { data }
    } else if (chartData) {
      payload = { data: { chart: chartData } }
    } else if (comprehensiveProfile?.medicalAstrology || comprehensiveProfile?.['Medical Astrology']) {
      const med = comprehensiveProfile.medicalAstrology ?? comprehensiveProfile['Medical Astrology']
      const chart = med.chart ?? med.data?.chart
      if (!chart) {
        return NextResponse.json(
          {
            error:
              'Medical Astrology requires chart data. Generate your medical astrology analysis first to use Ask the Seer.',
          },
          { status: 400 }
        )
      }
      payload = { data: { chart, timing: med.timing ?? med.data?.timing } }
    } else {
      return NextResponse.json(
        {
          error:
            'Medical Astrology requires chart data. Generate your medical astrology analysis first to use Ask the Seer.',
        },
        { status: 400 }
      )
    }

    // Build state; throw if no chart/planets
    let state
    try {
      state = buildMedicalAstrologyState(payload)
    } catch {
      return NextResponse.json(
        {
          error:
            'Medical Astrology requires chart data. Generate your medical astrology analysis first to use Ask the Seer.',
        },
        { status: 400 }
      )
    }

    const slice = getMedicalAstrologySliceForQuestionType(questionType, state)
    const displayName = (userProfile?.displayName ?? '').trim()
    const systemPrompt = buildMedicalAstrologySeerSystemPrompt(slice, questionType, {
      displayName: displayName || undefined,
    })

    const result = await callTextAI({
      label: 'medical-seer-chat',
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: question,
        },
      ],
      model: 'llama-3.3-70b-versatile',
      temperature: 0.6,
      maxTokens: 800,
      maxAttempts: 2,
    })

    let response = result.content || 'I apologize, I could not generate a response at this time.'

    // Post-process: ensure MEDICAL_DISCLAIMER is present
    if (!response.includes(MEDICAL_DISCLAIMER)) {
      response = `${response.trim()}\n\n${MEDICAL_DISCLAIMER}`
    }

    return NextResponse.json({
      response,
      timestamp: new Date().toISOString(),
    })
  } catch (error: unknown) {
    devLog.error('Medical Seer API error:', error, 'route')
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'An error occurred processing your request.',
      },
      { status: 500 }
    )
  }
}
