"use client";

import { Heart, MessageCircle, Sparkles } from "lucide-react";

const features = [
  {
    icon: Heart,
    title: "Love & relationships",
    description:
      "Ask about connection, compatibility, or timing—patterns from your chart and traditions, explained in plain language.",
  },
  {
    icon: Sparkles,
    title: "Career, money & timing",
    description:
      "Direction and tension across Vedic, numerology, and more—one profile, one conversation, not five conflicting apps.",
  },
  {
    icon: MessageCircle,
    title: "One clear answer",
    description:
      "AI connects patterns across traditions, grounded in your saved reports—not generic horoscope filler.",
  },
];

/**
 * Landing feature grid — no React hooks and no framer-motion so first paint cannot hit
 * stale HMR chunks (useState/useEffect undefined) and the landing bundle stays smaller.
 */
export function FeatureBlocks() {
  return (
    <section className="py-6 sm:py-8 md:py-10 bg-transparent" aria-labelledby="features-heading">
      <h2 id="features-heading" className="sr-only">
        Features
      </h2>
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group relative p-6 sm:p-8 rounded-3xl border border-white/10 bg-white/5 md:backdrop-blur-md fs-mobile-solid-card transition-all duration-300 md:duration-500 md:hover:bg-white/10 md:hover:border-amber-500/40 md:hover:shadow-[0_0_40px_rgba(245,158,11,0.2)] md:hover:-translate-y-1 cursor-default animate-in fade-in slide-in-from-bottom-2 fill-mode-both"
              style={{ animationDelay: `${index * 75}ms` }}
            >
              <div className="absolute inset-0 rounded-3xl bg-amber-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="relative z-10 text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 group-hover:border-amber-500/50 transition-all duration-500">
                  <feature.icon className="w-8 h-8 text-amber-500 group-hover:drop-shadow-[0_0_8px_rgba(245,158,11,0.6)] transition-all" />
                </div>
                <h3 className="text-xl font-heading text-white group-hover:text-amber-400 transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed font-light group-hover:text-white transition-colors duration-300">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
